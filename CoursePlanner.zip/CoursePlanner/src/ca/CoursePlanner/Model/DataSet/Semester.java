/**
 * Semester is the enum for three terms in a year.
 * 
 * @author Lawson Li
 */
package ca.CoursePlanner.Model.DataSet;

public enum Semester {
	SPRING, SUMMER, FALL;
}
